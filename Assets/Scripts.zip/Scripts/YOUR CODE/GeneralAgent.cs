﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// A flock leader. Behaves exactly like AllyAgent (mouse seek, attacks, right-click toggle)
/// but registers itself so PawnAgents can find and follow it.
/// </summary>
public class GeneralAgent : AllyAgent
{
    static readonly List<GeneralAgent> All = new List<GeneralAgent>();

    protected override void InitialiseFromAwake()
    {
        base.InitialiseFromAwake(); // adds SeekToMouse
        All.Add(this);
    }

    public Vector3 Velocity { get { return CurrentVelocity; } }

    public static GeneralAgent Nearest(Vector3 position)
    {
        GeneralAgent best = null;
        float bestSqr = float.MaxValue;

        for (int i = All.Count - 1; i >= 0; i--)
        {
            GeneralAgent g = All[i];
            if (g == null) { All.RemoveAt(i); continue; } // destroyed

            float sqr = (g.transform.position - position).sqrMagnitude;
            if (sqr < bestSqr) { bestSqr = sqr; best = g; }
        }
        return best;
    }
}