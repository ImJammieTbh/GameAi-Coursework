﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Follows its nearest General. Steering = follow + separation + alignment + cohesion,
/// where the neighbour rules only consider pawns that follow the same General.
/// </summary>
public class PawnAgent : SteeringAgent
{
	[Header("Follow")]
	public float followDistance = 2.0f;   // pawns relax inside this radius
	public float slowRadius = 2.0f;       // ease off as they approach followDistance

	[Header("Neighbours")]
	public float neighbourRadius = 3.0f;
	public float separationRadius = 1.0f;

	[Header("Weights")]
	public float followWeight = 1.5f;
	public float separationWeight = 2.0f;
	public float alignmentWeight = 0.6f;
	public float cohesionWeight = 0.4f;

	public float maxFlockSteering = 10.0f;
	public float pawnMaxSpeed = 6.0f;     // keep above the general's speed so pawns can catch up

	static readonly List<PawnAgent> All = new List<PawnAgent>();
	GeneralAgent general;

	protected override void InitialiseFromAwake()
	{
		// No SeekToMouse: pawns are driven by the general instead
		All.Add(this);
	}

	protected override void CooperativeArbitration(float deltaTime)
	{
		base.CooperativeArbitration(deltaTime);

		// Assign lazily so it doesn't matter what order Awake ran in
		if (general == null)
		{
			general = GeneralAgent.Nearest(transform.position);
		}

		if (general != null)
		{
			Vector3 separation, alignment, cohesion;
			Flock(out separation, out alignment, out cohesion);

			Vector3 force =
				Follow() * followWeight +
				separation * separationWeight +
				alignment * alignmentWeight +
				cohesion * cohesionWeight;

			force.z = 0.0f;
			SteeringVelocity += Vector3.ClampMagnitude(force, maxFlockSteering);
		}

		if (Input.GetKey(KeyCode.Space))
		{
			AttackWith(Attack.AttackType.AllyGun);
		}
	}

	Vector3 Follow()
	{
		Vector3 to = general.transform.position - transform.position;
		to.z = 0.0f;
		float dist = to.magnitude;

		if (dist <= followDistance)
		{
			return -CurrentVelocity * 0.5f; // gentle braking inside the leash
		}

		float t = Mathf.Clamp01((dist - followDistance) / slowRadius);
		Vector3 desired = to.normalized * (pawnMaxSpeed * t);
		return desired - CurrentVelocity;
	}

	void Flock(out Vector3 separation, out Vector3 alignment, out Vector3 cohesion)
	{
		separation = alignment = cohesion = Vector3.zero;
		Vector3 centre = Vector3.zero;
		int count = 0;

		float nSqr = neighbourRadius * neighbourRadius;
		float sSqr = separationRadius * separationRadius;

		for (int i = All.Count - 1; i >= 0; i--)
		{
			PawnAgent other = All[i];
			if (other == null) { All.RemoveAt(i); continue; } // destroyed
			if (other == this || other.general != general) continue;

			Vector3 offset = transform.position - other.transform.position;
			offset.z = 0.0f;
			float sqr = offset.sqrMagnitude;
			if (sqr > nSqr) continue;

			count++;
			centre += other.transform.position;
			alignment += other.CurrentVelocity;

			if (sqr < sSqr && sqr > 0.0001f)
			{
				separation += offset / sqr; // closer = stronger push
			}
		}

		if (count > 0)
		{
			alignment = (alignment / count) - CurrentVelocity;
			cohesion = (centre / count) - transform.position;
			cohesion.z = 0.0f;
		}
	}
}